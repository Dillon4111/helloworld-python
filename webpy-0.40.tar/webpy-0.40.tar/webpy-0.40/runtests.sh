#! /bin/bash

py.test tests $*
